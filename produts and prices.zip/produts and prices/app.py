from flask import Flask, render_template, request
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        products = request.form.getlist('product')
        prices = [float(price) for price in request.form.getlist('price')]

        if len(products) != len(prices):
            return "Error: Please provide the same number of products and prices."

        # Generate bar chart
        plt.figure(figsize=(10, 6))
        plt.bar(products, prices)
        plt.xlabel('Products')
        plt.ylabel('Prices')
        plt.title('Product Prices Visualization')

        # Save the plot to a byte buffer
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)

        # Encode the plot to base64
        plot_url = base64.b64encode(buf.read()).decode()

        # Render the template with the plot
        return render_template('result.html', plot_url=plot_url)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)